﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Randomized
{
    public class Randomized
    {
        public int[] Randomizer(int minValue, int maxValue, int qualityValues, bool repetitive)
        {
            var randNums = new List<int>(qualityValues);
            var random = new Random();
            maxValue++;
            if (repetitive)
            {
                int i = 0;
                while (true)
                {
                    if (i == 0)
                    {
                        randNums.Add(random.Next(minValue, maxValue));
                        i++;
                        continue;
                    }
                    i++;
                    var num = random.Next(minValue, maxValue);
                    if (randNums.Contains(num))
                    {
                        i--;
                        continue;
                    }

                    randNums.Add(num);
                    if (i == qualityValues) break;
                }
            }
            else
            {
                int i = 0;
                while (true)
                {
                    randNums.Add(random.Next(minValue, maxValue));
                    i++;
                    if (i == qualityValues) break;
                }
            }
            var randNumsArray = randNums.ToArray();
            return randNumsArray;
        }
    }
}

